// Copyright (c) 2024 Intel Corporation
// SPDX-License-Identifier: 0BSD
void bar();
