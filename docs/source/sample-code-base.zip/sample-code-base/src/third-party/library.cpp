// Copyright (c) 2024 Intel Corporation
// SPDX-License-Identifier: 0BSD
#include <cstdio>

void bar()
{
    printf("Running third-party library code.\n");
}
